﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using Unittype = UnitConversion.Constant.Constant.UnitType;
namespace UnitConversion.Models
{
   public class UnitModel
    {
       public Unittype FromUnit { get; set; }
       public Unittype ToUnit { get; set; }
       public double InPutUnit { get; set; }
       public double CalculateUnit()
       {
              XDocument document = XDocument.Load(@"C:\Users\Rajesh\Documents\Visual Studio 2012\Projects\ExerciseTest\WebApplication1\Unit.xml");
           var selectedBookAttribute = (from item in document.Descendants("Unit").Where
                                        (item => (string)item.Attribute("id") == FromUnit.ToString())
                                        select new
                                        {
                                            valued = item.Element(ToUnit.ToString()).Value

                                        });
                                                  
           return InPutUnit * (Convert.ToDouble(selectedBookAttribute.First().valued));
       }




      
    }


}
