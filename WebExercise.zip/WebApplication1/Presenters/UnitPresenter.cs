﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 using UnitConversion.Models;
using UnitConversion.Views;
using UnitConversion.Constant;
namespace UnitConversion.Presenters
{
    public class UnitPresenter
    {
        IUnit unitView;

        public UnitPresenter(IUnit view)
        {
            unitView = view;



        }

        public void CalculateUnit()
        {
            UnitModel unitModel = new UnitModel();
            unitModel.FromUnit =UnitConversion.Constant.Constant.GetUnitType(unitView.FromUnitText);
            unitModel.ToUnit= UnitConversion.Constant.Constant.GetUnitType(unitView.ToUnitText);
            unitModel.InPutUnit =Convert.ToDouble( unitView.InPutUnitText) ;
            unitView.TotalUnitText = unitModel.CalculateUnit().ToString();

        }
            
    }
}
