﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnitConversion.Models;
namespace UnitConversion.Views
{
   public interface IUnit
    {

       string FromUnitText { get;set;}
       string ToUnitText { get;set;}
       string InPutUnitText { get; set; }
       string TotalUnitText { get; set; }
    }
}
