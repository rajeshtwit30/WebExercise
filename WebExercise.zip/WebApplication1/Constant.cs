﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitConversion.Constant
{
   public  class Constant
    {

      public enum UnitType
        {
            MilliGram,
            Gram,
            KiloGram,
            Ounce,
            Pound,
            Stone


        }

        public static UnitType GetUnitType(string inputType)
        {
            UnitType unittype = UnitType.MilliGram; 
            switch (inputType)
            {
                case "MilliGram":
                    unittype = UnitType.MilliGram;
                    break;

                case "Gram":
                    unittype = UnitType.Gram;
                    break;

                case "KiloGram":
                    unittype = UnitType.KiloGram;
                    break;

                case "Ounce":
                    unittype = UnitType.Ounce;
                    break;

                case "Pound":
                    unittype = UnitType.Pound;
                    break;

                case "Stone":
                    unittype = UnitType.Stone;
                    break;

            }

            return unittype;
        }
    }


   public static class UnitConstant
   {

       public static double GetValues()
       {


           return 1;

       }
   }
}
