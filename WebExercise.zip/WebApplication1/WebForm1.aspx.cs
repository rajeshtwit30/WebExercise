﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UnitConversion.Presenters;
using UnitConversion.Views;

namespace WebApplication1
{
    public partial class WebForm1 : System.Web.UI.Page,IUnit
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        public string FromUnitText
        {
            get
            {
                return drpFromUnit.SelectedItem.ToString();
            }
            set
            {
                drpFromUnit.SelectedItem.Value = value;
            }
        }

        public string ToUnitText
        {
            get
            {
                return drpToUnit.SelectedItem.ToString();
            }
            set
            {
                drpToUnit.SelectedItem.Value = value;
            }
        }

        public string InPutUnitText
        {
            get
            {
                return txtInputVal.Text;
            }
            set
            {
                txtInputVal.Text = value;
            }
        }

        public string TotalUnitText
        {
            get
            {
                return txtCalculate.Text;
            }
            set
            {
                txtCalculate.Text = value;
            }
        }

        protected void drpToUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (drpFromUnit.SelectedIndex != -1 && !string.IsNullOrWhiteSpace(txtInputVal.Text))
            {
                UnitPresenter presenter = new UnitPresenter(this);
                presenter.CalculateUnit();
            }
        }

        protected void drpFromUnit_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (drpToUnit.SelectedIndex != -1 && !string.IsNullOrWhiteSpace(txtInputVal.Text))
            {
                UnitPresenter presenter = new UnitPresenter(this);
                presenter.CalculateUnit();
            }
        }
    }
}